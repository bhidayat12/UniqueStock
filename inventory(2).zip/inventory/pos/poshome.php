<?php 
include_once 'php_action/db_connect.php'; 
include_once 'includes/style.php'; 
?>
<h1>
	<i class='glyphicon glyphicon-circle-arrow-right'></i>
 	Come Anna you are in POS HOME
</h1>




<?php include_once 'includes/footer.php'; ?>


