
<?php 
require_once 'core.php';

	$startDate = $_POST['startDate1'];
	$date = DateTime::createFromFormat('m/d/Y',$startDate);
	$start_date = $date->format("Y-m-d");


	$endDate = $_POST['endDate1'];
	$format = DateTime::createFromFormat('m/d/Y',$endDate);
	$end_date = $format->format("Y-m-d");

          
        $sql = "SELECT sub_total FROM orders WHERE order_date >= '$start_date' AND order_date <= '$end_date' and order_status = 1";
	$query = $connect->query($sql);
	$totalAmount = 0;
                 While ($result = $query->fetch_assoc()) {
		 $totalAmount += $result['sub_total'];
		}
	$sql1 = "SELECT CostPrice FROM product WHERE product_id in (select product_id from order_item where order_id in( SELECT order_id FROM orders WHERE order_date >= '$start_date' AND order_date <= '$end_date' and order_status = 1))";
	$query1 = $connect->query($sql1);
        $sql2 = "select quantity from order_item where order_id in( SELECT order_id FROM orders WHERE order_date >= '$start_date' AND order_date <= '$end_date' and order_status = 1)";
	$query2 = $connect->query($sql2);
	
        	while ($result1 = $query1->fetch_assoc()) {
		$costPrice = $result1['CostPrice'];
		}
                $quantity =0;
                while ($result2 = $query2->fetch_assoc()) {
		$quantity += $result2['quantity'];
		}
                $totalCost = $costPrice * $quantity;
                
                
                
	      $totalprofit =  $totalAmount - $totalCost ;
                 
	$table = '
           
            <table cellspacing="0" cellpadding="0" style="border:1px solid black; width:100%;">
                <tr>
                <th style="background-color: #000000; color: white; padding: 8px;"><center> </center></th>
                <th style="background-color: #000000; color: white; padding: 8px;"><center> Profit Report</center></th>
                <th style="background-color: #000000; color: white; padding: 8px;"><center></center></th>
                </tr>
		<tr>
			<th style="background-color: #4CAF50; color: white; padding: 8px; border:1px solid black;"><center>Total Cost</center></th>
                        <th style="background-color: #4CAF50; color: white; padding: 8px; border:1px solid black;"><center>Total Sales</center></th>
                        <th style="background-color: #4CAF50; color: white; padding: 8px; border:1px solid black;"><center>Total Profit</center></th>
                 </tr>       
			
		
                <tr style ="background-color: #f2f2f2";>
			<td style="padding: 8px; border-bottom: 1px solid #ddd;border:1px solid black;"><center>'.$totalCost.'</center></td>
			<td style="padding: 8px; border-bottom: 1px solid #ddd;border:1px solid black;"><center>'.$totalAmount.'</center></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;border:1px solid black;"><center>'.$totalprofit.'</center></td>
		</tr>
             
	</table>
     

                ';
	echo $table;


?>