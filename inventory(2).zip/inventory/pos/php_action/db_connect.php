<?php 	

$localhost = "localhost";
$username = "uniqumqz_root";
$password = "Mustak@123";
$dbname = "uniqumqz_stock";

// db connection
$connect = new mysqli($localhost, $username, $password, $dbname);
// check connection
if($connect->connect_error) {
  die("Connection Failed : " . $connect->connect_error);
} else {
  // echo "Successfully connected";
}

?>