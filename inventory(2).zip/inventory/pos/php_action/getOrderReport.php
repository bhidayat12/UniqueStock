<?php 

require_once 'core.php';

if($_POST) {

	$startDate = $_POST['startDate'];
	$date = DateTime::createFromFormat('m/d/Y',$startDate);
	$start_date = $date->format("Y-m-d");


	$endDate = $_POST['endDate'];
	$format = DateTime::createFromFormat('m/d/Y',$endDate);
	$end_date = $format->format("Y-m-d");

	$sql = "SELECT * FROM orders WHERE order_date >= '$start_date' AND order_date <= '$end_date' and order_status = 1";
	$query = $connect->query($sql);

	$table = '
	<table cellspacing="0" cellpadding="0" style="border:1px solid black; width:100%;">
		<tr>
                <th style="background-color: #000000; color: white; padding: 8px;"><center> </center></th>
                 <th style="background-color: #000000; color: white; padding: 8px;"><center> </center></th>
                <th style="background-color: #000000; color: white; padding: 8px;"><center> Sales Report</center></th>
                <th style="background-color: #000000; color: white; padding: 8px;"><center></center></th>
                <th style="background-color: #000000; color: white; padding: 8px;"><center></center></th>
                </tr>


                <tr>
			<th style="background-color: #4CAF50; color: white; padding: 8px; border:1px solid black;">Order Date</th>
			<th style="background-color: #4CAF50; color: white; padding: 8px; border:1px solid black;">Client Name</th>
			<th style="background-color: #4CAF50; color: white; padding: 8px; border:1px solid black;">Contact</th>
			<th style="background-color: #4CAF50; color: white; padding: 8px; border:1px solid black;">Total</th>
                        <th style="background-color: #4CAF50; color: white; padding: 8px; border:1px solid black;">Total with tax</th>
		</tr>

		<tr>';
		$totalAmount = 0;
                $totalsale=0;
		while ($result = $query->fetch_assoc()) {
			$table .= '<tr style ="background-color: #f2f2f2";>
				<td style="padding: 8px; border-bottom: 1px solid #ddd;border:1px solid black;"><center>'.$result['order_date'].'</center></td>
				<td style="padding: 8px; border-bottom: 1px solid #ddd;border:1px solid black;"><center>'.$result['client_name'].'</center></td>
				<td style="padding: 8px; border-bottom: 1px solid #ddd;border:1px solid black;"><center>'.$result['client_contact'].'</center></td>
				<td style="padding: 8px; border-bottom: 1px solid #ddd;border:1px solid black;"><center>'.$result['sub_total'].'</center></td>
			        <td style="padding: 8px; border-bottom: 1px solid #ddd;border:1px solid black;"><center>'.$result['grand_total'].'</center></td>
                        </tr>';	
                        $totalsale += $result['sub_total'];
			$totalAmount += $result['grand_total'];
		}
		$table .= '
		</tr>

		<tr>
			<td colspan="3" style ="background-color: #f2f2f2";><center>Total Sales</center></td>
			<td style ="padding: 8px; border-bottom: 1px solid #ddd;border:1px solid black;";><center>'.$totalsale.'</center></td>
                        <td style ="padding: 8px; border-bottom: 1px solid #ddd;border:1px solid black;";><center>'.$totalAmount.'</center></td>
		</tr>
	</table>
	';	

	echo $table;

}

?>